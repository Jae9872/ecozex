var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1704661775577.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-bf3793bb-2e91-4906-8a08-5c374b531345" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Contact"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/bf3793bb-2e91-4906-8a08-5c374b531345-1704661775577.css" />\
      <div class="freeLayout">\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Module 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_2" class="button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="164.3px" datasizeheight="46.3px" dataX="585.8" dataY="746.4" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">Send message</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Fields" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Field 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Input_1" class="text firer commentable non-processed" customid="Input"  datasizewidth="632.2px" datasizeheight="37.3px" dataX="355.3" dataY="297.1" ><div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="something@website.com"/></div></div>  </div></div></div>\
            <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Your Email Address"   datasizewidth="223.0px" datasizeheight="25.2px" dataX="356.4" dataY="263.9" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_7_0">Your Email Address</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Field 3" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Input_2" class="text firer commentable non-processed" customid="Input"  datasizewidth="632.2px" datasizeheight="194.4px" dataX="355.3" dataY="499.6" ><div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Your message stars with..."/></div></div>  </div></div></div>\
            <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Message"   datasizewidth="223.0px" datasizeheight="25.2px" dataX="356.4" dataY="465.3" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_8_0">Message</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Field 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Input_3" class="text firer commentable non-processed" customid="Input"  datasizewidth="632.2px" datasizeheight="37.3px" dataX="355.3" dataY="396.8" ><div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Question about your article"/></div></div>  </div></div></div>\
            <div id="s-Paragraph_9" class="richtext manualfit firer ie-background commentable non-processed" customid="Subject"   datasizewidth="223.0px" datasizeheight="25.2px" dataX="356.4" dataY="362.6" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_9_0">Subject</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
        <div id="s-Paragraph_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Tittle h2"   datasizewidth="468.2px" datasizeheight="69.5px" dataX="448.9" dataY="176.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">Contact Us</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="Top menu" datasizewidth="1007.0px" datasizeheight="44.7px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Container"   datasizewidth="1364.8px" datasizeheight="110.8px" datasizewidthpx="1364.7623109219244" datasizeheightpx="110.79507378084685" dataX="0.5" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer commentable non-processed" customid="Menu_Button"   datasizewidth="160.1px" datasizeheight="40.3px" dataX="1056.4" dataY="37.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">Get started</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_11" class="richtext manualfit firer ie-background commentable non-processed" customid="Menu_Option 3"   datasizewidth="105.6px" datasizeheight="23.2px" dataX="903.8" dataY="46.4" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_11_0">Subscribe</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_12" class="richtext manualfit firer click ie-background commentable non-processed" customid="Menu_Option 2"   datasizewidth="105.6px" datasizeheight="23.2px" dataX="761.9" dataY="46.4" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_12_0">Home</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Menu_Option 1"   datasizewidth="118.4px" datasizeheight="25.2px" dataX="612.5" dataY="45.4" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_13_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Footer" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Container"   datasizewidth="1365.8px" datasizeheight="430.4px" datasizewidthpx="1365.8293651134186" datasizeheightpx="430.3602400104164" dataX="0.5" dataY="841.1" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Icon rrss" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Path_1" class="path firer commentable non-processed" customid="Icon facebook"   datasizewidth="32.2px" datasizeheight="28.5px" dataX="1061.1" dataY="1204.7"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="32.196083068847656" height="28.538679122924805" viewBox="1061.1140460091212 1204.7326645099988 32.196083068847656 28.538679122924805" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_1-bf379" d="M1079.8067525185095 1233.2713427942083 C1079.8067525185095 1229.9749693473605 1079.8067525185095 1226.9153516413903 1079.8067525185095 1223.6675437938839 C1082.4926865056839 1223.4186463456067 1084.595886475692 1222.6476713458405 1083.5308901650462 1219.5577005383059 C1082.41230927046 1219.4120044730075 1081.2334454694176 1219.266308407709 1079.8938277568593 1219.090258996604 C1079.5522252058227 1216.6559203788836 1079.0498685037278 1214.3915609246505 1082.9883449651104 1214.033391330155 C1083.4973997501788 1213.9848259750554 1084.1806048522521 1212.7585507881927 1084.1940010181993 1212.0725650626061 C1084.2006991074109 1211.6172648483716 1083.2227780288767 1210.852360494247 1082.5730633416706 1210.7309470748373 C1078.1188338525512 1209.8871240198068 1075.2252591335043 1211.8722329422906 1074.8099776697595 1215.9395814793645 C1074.709506325348 1216.9169592812723 1074.689412056466 1217.9004077469135 1074.6224311668454 1219.090258996604 C1071.6886679499578 1219.1266830129287 1069.6457508864057 1219.8733753419297 1071.233197988372 1223.121183478908 C1072.1776285659532 1223.2425968711798 1073.235926713778 1223.3761515909189 1074.528658005217 1223.5339890108228 C1074.528658005217 1226.8182211302033 1074.528658005217 1230.0174642467844 1074.528658005217 1233.2470602478256 C1066.2833100597882 1232.27575336294 1060.6368208831454 1225.786208476397 1061.145875660728 1218.12502302874 C1061.6281380814646 1210.7491597897185 1068.687924562077 1204.7938330810669 1077.0270456890962 1204.733126384931 C1085.547015535484 1204.6724196887951 1092.7675556880695 1210.6034638601102 1093.276610632833 1218.0946701442797 C1093.7990607853737 1225.7194307411182 1088.1659677347543 1232.2211172446007 1079.8067525185095 1233.2713427942083 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-bf379" fill="#000000" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Icon Instagram" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Path_2" class="path firer commentable non-processed" customid="Path 67"   datasizewidth="32.3px" datasizeheight="28.1px" dataX="1199.8" dataY="1204.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="32.279632568359375" height="28.06622314453125" viewBox="1199.8310867703335 1204.7326645324447 32.279632568359375 28.06622314453125" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_2-bf379" d="M1215.846896803252 1232.7928164171994 C1212.7322851863858 1232.7928164171994 1209.624371812188 1232.8049577559743 1206.5097605147114 1232.7928164171994 C1202.8793960298033 1232.7746044090372 1200.139877378841 1230.6802234115726 1200.0059157193716 1227.3838499647245 C1199.8183692164578 1222.6183744469645 1199.7312940579552 1217.8346870827395 1200.0059157193716 1213.075282083977 C1200.307329732644 1207.8848595259149 1203.6161857956645 1205.0680692377082 1209.3765425824745 1204.8555955728211 C1213.703508335403 1204.6916874891836 1218.0505681775571 1204.6916874891836 1222.3775339304857 1204.8555955728211 C1228.7474170663559 1205.0923516755388 1232.0227823551954 1208.2733825838147 1232.0763670189833 1214.0344478223155 C1232.1165555542525 1217.8104041383326 1232.1299517326756 1221.5924312628194 1232.0696689297718 1225.3683878683087 C1231.9892918592332 1230.5527396179011 1229.4641120979738 1232.7988872256692 1223.8444153729965 1232.7988872256692 C1221.178570211354 1232.7928164171994 1218.5127437277763 1232.7928164171994 1215.846896803252 1232.7928164171994 Z M1228.6871431028137 1218.7999247874359 C1228.7072373704484 1218.7999247874359 1228.7340297285423 1218.7999247874359 1228.7541239974246 1218.7999247874359 C1228.7541239974246 1216.7116144367437 1228.7675201758475 1214.6233040860513 1228.7541239974246 1212.5349940248313 C1228.7407278190014 1210.0885140796436 1227.106393989002 1208.3826559783815 1224.6883836401562 1208.2491013762403 C1219.2763274873564 1207.9455679000841 1213.8240831561054 1207.9819919186702 1208.4053287606373 1208.212677359916 C1205.0830764118984 1208.3523027614806 1203.37506349702 1210.1795742911984 1203.3415732418475 1213.111707479817 C1203.294686616119 1217.4825894206795 1203.5023273829247 1221.8534713615418 1203.509025475879 1226.2243538813484 C1203.5157235650906 1229.1443458872357 1205.3309058013067 1230.3888332552656 1208.2981594330618 1230.437398565135 C1213.1877647945412 1230.5223879388207 1218.0840677599094 1230.5405999481138 1222.9803713640572 1230.437398565135 C1226.5571511851776 1230.3584798642291 1228.5866720827826 1228.3490882144429 1228.6737473211326 1225.0587855760646 C1228.7340141932232 1222.982615718346 1228.6871431028137 1220.888234269712 1228.6871431028137 1218.7999247874359 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-bf379" fill="#000000" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_3" class="path firer commentable non-processed" customid="Path 68"   datasizewidth="17.0px" datasizeheight="15.3px" dataX="1207.3" dataY="1211.5"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="17.000823974609375" height="15.287127494812012" viewBox="1207.30046092231 1211.5023762490673 17.000823974609375 15.287127494812012" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_3-bf379" d="M1216.7724511306703 1226.789495774728 C1211.8560534372973 1226.7955664441154 1207.3683336930055 1223.2381541615932 1207.301352543881 1219.2679360271538 C1207.23437164927 1215.4191314568602 1210.991999935245 1211.5521150401016 1214.8567971645298 1211.503549730232 C1220.1951742449264 1211.430701697583 1224.267612844863 1214.7574286756803 1224.301103419425 1219.2132999088146 C1224.3278951125394 1223.4506275370081 1221.0190373327987 1226.7834261241467 1216.7724511306703 1226.789495774728 Z M1220.8515850987674 1219.692883935872 C1220.8716793664018 1216.5543477461 1218.714894554197 1214.5570974961488 1215.3591519502856 1214.611733614488 C1212.3852002355572 1214.6602989695875 1210.5030371633686 1216.475429117562 1210.5700179931034 1219.2436545301073 C1210.6236027067957 1221.6597810118908 1213.456894469482 1223.9362820830634 1216.4107520949847 1223.9302112745936 C1219.096688956667 1223.9180693681822 1220.8381962787853 1222.2607768662617 1220.8515850987674 1219.692883935872 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-bf379" fill="#000000" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_4" class="path firer commentable non-processed" customid="Path 69"   datasizewidth="3.6px" datasizeheight="4.3px" dataX="1223.3" dataY="1207.6"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="3.596649169921875" height="4.285892486572266" viewBox="1223.3063060976197 1207.6339699757648 3.596649169921875 4.285892486572266" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_4-bf379" d="M1225.3161954608208 1211.9198621475177 C1224.3181801396047 1210.8453536535035 1223.2062972481447 1210.141155936716 1223.3134667354152 1209.6433610763456 C1223.4675227935188 1208.8966687134223 1224.4856323736362 1208.2956724248434 1225.1353470608422 1207.6339694989276 C1225.764967459204 1208.2106830963878 1226.8031713181847 1208.7388313839785 1226.896944639508 1209.3762515825915 C1226.9840131706724 1209.9954598623713 1226.1065650996227 1210.7300108978272 1225.3161954608208 1211.9198621475177 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-bf379" fill="#FFFFFF" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Path_5" class="path firer commentable non-processed" customid="Icon tweter"   datasizewidth="32.1px" datasizeheight="25.0px" dataX="1130.5" dataY="1206.7"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="32.05035400390625" height="24.97601890563965" viewBox="1130.4725684601185 1206.666868067763 32.05035400390625 24.97601890563965" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_5-bf379" d="M1130.4725684601185 1229.5035250546127 C1133.6809532386133 1228.5565006437416 1136.2731137447695 1227.815878944552 1138.8451801617 1227.0145506080253 C1139.3207444919772 1226.8688545427267 1139.695837497805 1226.4681903654175 1140.091024792477 1226.2010808716632 C1137.813674345769 1224.9869469670377 1135.6903799671454 1223.8456610272167 1132.9508616355731 1222.3826297647743 C1134.4646298248313 1221.981965560327 1135.167929175825 1221.7937748036627 1136.1659446567362 1221.53273604601 C1134.216800595118 1219.9179379007535 1131.671526669776 1218.527754747851 1131.6581305038292 1216.2876773696087 C1132.126996751133 1216.1176986222374 1132.5958629984368 1215.9477198748662 1133.064729205817 1215.777741145587 C1132.435108807455 1213.197706598258 1131.8121864920663 1210.6237428593988 1131.1825661336281 1208.04370831207 C1131.5777533883765 1207.794810863793 1131.9729406431247 1207.539842751782 1132.3681279377965 1207.2909452854128 C1135.3956643163128 1211.9046540650947 1139.8297997162067 1214.0658123805913 1145.4294021922635 1214.1447311538652 C1145.6437410470332 1213.9383283879079 1145.904966522541 1213.8108443228564 1145.9183627284115 1213.6590775847783 C1146.6551525741202 1206.7810090613912 1149.6224062857227 1205.293695144014 1156.970210174499 1207.8190935730036 C1158.1892624733823 1208.237969768652 1159.863784893546 1207.582337470286 1161.578495731703 1207.3941467136215 C1161.4378358595081 1207.7219628808966 1161.31057215326 1208.122627085344 1161.1029314014258 1208.492937862571 C1160.8818944437207 1208.899672730752 1160.5871785333838 1209.2760542078965 1160.1785950727651 1209.8770504964755 C1161.1163275673728 1209.78599045001 1161.7258536768904 1209.7252837583972 1162.5229263492079 1209.6463650574913 C1162.3755683840586 1210.0166759070862 1162.3554741151763 1210.3627040293784 1162.161229509327 1210.484117448788 C1159.783407818017 1211.916795392562 1159.394918526471 1213.9322576337142 1159.394918526471 1216.3848083873718 C1159.4016166156825 1226.589603531539 1154.0900317012465 1231.3368669133622 1142.7099780297642 1231.5857654290676 C1138.6509400672314 1231.6828955060464 1134.538308497997 1231.9317928638634 1130.4725684601185 1229.5035250546127 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-bf379" fill="#000000" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Domain"   datasizewidth="220.9px" datasizeheight="23.2px" dataX="126.4" dataY="1208.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">&copy; 2024 EcoZex</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_6" class="path firer ie-background commentable non-processed" customid="Dividing line"   datasizewidth="1360.5px" datasizeheight="3.0px" dataX="5.9" dataY="1169.9"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="1360.5306396484375" height="2.0" viewBox="5.864508214485738 1169.8841063070258 1360.5306396484375 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_6-bf379" d="M6.864504816031172 1170.8841063070258 L1365.3951639138393 1170.8841063070258 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-bf379" fill="none" stroke-width="1.0" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Picture_Google play"   datasizewidth="131.3px" datasizeheight="40.6px" dataX="1108.1" dataY="1063.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/1feda9dd-c561-435f-a440-94f8eaef4cd1.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Picure_App store"   datasizewidth="130.6px" datasizeheight="40.6px" dataX="954.4" dataY="1064.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/4d278508-4bef-43ed-bcdb-fb9bc567e1cb.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Columns" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Column 4"   datasizewidth="227.1px" datasizeheight="193.4px" dataX="1065.4" dataY="885.6" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Other possibilities<br /></span><span id="rtr-s-Paragraph_2_1">Give away<br />subscribe<br /><br /></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Column 2"   datasizewidth="171.1px" datasizeheight="193.4px" dataX="846.8" dataY="886.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">Help and services<br /></span><span id="rtr-s-Paragraph_3_1">How does it work<br />FAQS<br />Contact</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Column 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Tittle"   datasizewidth="394.9px" datasizeheight="35.8px" dataX="92.4" dataY="887.5" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_4_0">Sign up for our newsletter</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Button "   datasizewidth="164.7px" datasizeheight="40.6px" dataX="92.4" dataY="1065.5" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Button_1_0">Subscribe</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="334.5px" datasizeheight="92.8px" dataX="92.4" dataY="926.2" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_5_0">Don&#039;t worry, we reserve our newsletter for important news so we only send a few updates a year.</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;