var content='<div class="ui-page " deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1704661775577.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Landing"width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1704661775577.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="1366.0px" datasizeheight="764.0px" datasizewidthpx="1365.9999999999995" datasizeheightpx="764.0000000000001" dataX="0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1145.0px" datasizeheight="540.2px" dataX="0.0" dataY="63.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d83bc7d9-22ad-4f25-86da-8945eb0a4779.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_40" class="path firer commentable non-processed" customid="Menu icon"   datasizewidth="18.8px" datasizeheight="13.6px" dataX="19.0" dataY="19.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.83333396911621" height="13.5600004196167" viewBox="19.00000000000034 19.0 18.83333396911621 13.5600004196167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_40-d1224" d="M37.83333333333368 19.0 L37.83333333333368 20.506666666666668 L19.00000000000034 20.506666666666668 L19.00000000000034 19.0 L37.83333333333368 19.0 Z M37.83333333333368 31.05333333333333 L37.83333333333368 32.56 L19.00000000000034 32.56 L19.00000000000034 31.05333333333333 L37.83333333333368 31.05333333333333 Z M37.83333333333368 25.026666666666664 L37.83333333333368 26.53333333333333 L19.00000000000034 26.53333333333333 L19.00000000000034 25.026666666666664 L37.83333333333368 25.026666666666664 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_40-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="image-removebg-preview (1)"   datasizewidth="345.0px" datasizeheight="724.0px" dataX="997.0" dataY="199.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/546f2e79-1f65-4a74-83b1-a4fbfb509c9b.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="132.0px" datasizeheight="30.0px" dataX="1188.5" dataY="20.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">CONTACT</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer mouseenter mouseleave commentable non-processed" customid="Secondary button"   datasizewidth="132.0px" datasizeheight="30.0px" dataX="1037.5" dataY="20.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">DOWNLOAD</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="553.5px" datasizeheight="140.0px" datasizewidthpx="553.5" datasizeheightpx="140.0" dataX="46.0" dataY="63.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"><br /><br /></span><span id="rtr-s-Rectangle_2_1">&quot;Ready to Greenify Your Life? Let&rsquo;s Get This Eco Party Started! Click &#039;Download&#039; and Let the Fun Begin <br />Because Saving the Planet Can Be a Blast!&quot;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="1364.5px" datasizeheight="768.0px" datasizewidthpx="1364.5498938428873" datasizeheightpx="767.9999999999998" dataX="0.7" dataY="763.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Menu icon"   datasizewidth="18.8px" datasizeheight="13.6px" dataX="19.3" dataY="20.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.83333396911621" height="13.5600004196167" viewBox="19.274946921443828 19.99999999999966 18.83333396911621 13.5600004196167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-d1224" d="M38.10828025477716 19.99999999999966 L38.10828025477716 21.506666666666327 L19.274946921443828 21.506666666666327 L19.274946921443828 19.99999999999966 L38.10828025477716 19.99999999999966 Z M38.10828025477716 32.053333333332986 L38.10828025477716 33.55999999999966 L19.274946921443828 33.55999999999966 L19.274946921443828 32.053333333332986 L38.10828025477716 32.053333333332986 Z M38.10828025477716 26.026666666666323 L38.10828025477716 27.53333333333299 L19.274946921443828 27.53333333333299 L19.274946921443828 26.026666666666323 L38.10828025477716 26.026666666666323 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="image-removebg-preview (1)"   datasizewidth="345.0px" datasizeheight="724.0px" dataX="997.3" dataY="200.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/546f2e79-1f65-4a74-83b1-a4fbfb509c9b.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="h1. Heading"   datasizewidth="840.0px" datasizeheight="398.0px" dataX="502.3" dataY="1133.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Welcome Home to EcoZex &ndash; Where Sustainability Meets Quirkiness. Swipe, Tap, and Giggle Your Way Through &#039;Home&#039; to Uncover a Universe of Eco Awesomeness!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Footer" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Container"   datasizewidth="1365.8px" datasizeheight="464.4px" datasizewidthpx="1365.8293651134184" datasizeheightpx="464.3602408413942" dataX="0.0" dataY="1531.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Icon rrss" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Path_2" class="path firer commentable non-processed" customid="Icon facebook"   datasizewidth="32.2px" datasizeheight="30.8px" dataX="1060.7" dataY="1923.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="32.196083068847656" height="30.793336868286133" viewBox="1060.65186634206 1923.35831585708 32.196083068847656 30.793336868286133" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_2-d1224" d="M1079.3445728514482 1954.1516519723111 C1079.3445728514482 1950.5948532131033 1079.3445728514482 1947.2935147465373 1079.3445728514482 1943.789118443017 C1082.0305068386226 1943.5205572045904 1084.1337068086307 1942.6886724176372 1083.068710497985 1939.354582845736 C1081.9501296033986 1939.1973762692874 1080.7712658023563 1939.0401696928388 1079.431648089798 1938.8502117475168 C1079.0900455387614 1936.2235516573867 1078.5876888366665 1933.7802996936512 1082.5261652980491 1933.3938334179609 C1083.0352200831176 1933.3414312258112 1083.7184251851909 1932.0182759057575 1083.731821351138 1931.278094850139 C1083.7385194403494 1930.7868242877562 1082.7605983618155 1929.9614897492002 1082.1108836746093 1929.8304842346638 C1077.65665418549 1928.9199961350848 1074.763079466443 1931.0619357745798 1074.3477980026983 1935.4506194183475 C1074.2473266582867 1936.5052135682993 1074.2272323894047 1937.5663579861694 1074.1602514997842 1938.8502117475168 C1071.2264882828965 1938.889513391629 1069.1835712193445 1939.6951970898278 1070.7710183213107 1943.1995937056895 C1071.715448898892 1943.3305991909438 1072.7737470467168 1943.4747052120345 1074.0664783381558 1943.6450123536015 C1074.0664783381558 1947.1887105769729 1074.0664783381558 1950.64070536183 1074.0664783381558 1954.1254510177662 C1065.821130392727 1953.0774074090314 1060.1746412160842 1946.0751652260797 1060.6836959936668 1937.808718679999 C1061.1659584144033 1929.8501358192723 1068.2257448950156 1923.4243169642316 1076.564866022035 1923.3588142216047 C1085.0848358684227 1923.2933114789776 1092.3053760210082 1929.6929293892338 1092.8144309657716 1937.7759678089199 C1093.3368811183125 1946.0031118104666 1087.703788067693 1953.0184548415962 1079.3445728514482 1954.1516519723111 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-d1224" fill="#000000" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Icon Instagram" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Path_3" class="path firer commentable non-processed" customid="Path 67"   datasizewidth="32.3px" datasizeheight="30.3px" dataX="1199.4" dataY="1923.4"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="32.279632568359375" height="30.28355598449707" viewBox="1199.3689071032718 1923.3583158793513 32.279632568359375 30.28355598449707" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_3-d1224" d="M1215.3847171361904 1953.6353202970815 C1212.270105519324 1953.6353202970815 1209.1621921451263 1953.648420845119 1206.0475808476497 1953.6353202970815 C1202.4172163627416 1953.6156694750255 1199.6776977117793 1951.3558248751322 1199.54373605231 1947.7990261159243 C1199.356189549396 1942.6570609587868 1199.2691143908935 1937.4954451540652 1199.54373605231 1932.3600301086756 C1199.8451500655822 1926.7595455725761 1203.1540061286028 1923.7202187597654 1208.9143629154128 1923.4909589141137 C1213.2413286683413 1923.314101504628 1217.5883885104954 1923.314101504628 1221.915354263424 1923.4909589141137 C1228.2852373992941 1923.7464195971825 1231.560602688134 1927.1787633440285 1231.6141873519218 1933.394973376787 C1231.654375887191 1937.4692437700508 1231.667772065614 1941.5500645874035 1231.60748926271 1945.6243352930087 C1231.5271121921714 1951.218269405019 1229.0019324309121 1953.6418707211706 1223.3822357059348 1953.6418707211706 C1220.7163905442924 1953.6353202970815 1218.0505640607146 1953.6353202970815 1215.3847171361904 1953.6353202970815 Z M1228.2249634357522 1938.5369400956315 C1228.2450577033867 1938.5369400956315 1228.2718500614808 1938.5369400956315 1228.2919443303629 1938.5369400956315 C1228.2919443303629 1936.2836457453552 1228.305340508786 1934.030351395079 1228.2919443303629 1931.777057357144 C1228.2785481519397 1929.1372967311772 1226.6442143219406 1927.2966697282645 1224.2262039730947 1927.1525638340624 C1218.8141478202947 1926.8250501258071 1213.3619034890437 1926.8643517723597 1207.9431490935756 1927.1132621899503 C1204.620896744837 1927.2639184984805 1202.9128838299582 1929.2355510256903 1202.8793935747858 1932.3993332412897 C1202.8325069490572 1937.1155305152272 1203.040147715863 1941.8317277891645 1203.0468458088174 1946.5479256877848 C1203.053543898029 1949.6986075237182 1204.868726134245 1951.041413852501 1207.835979766 1951.093815995847 C1212.7255851274795 1951.185519834549 1217.6218880928477 1951.2051706578252 1222.5181916969957 1951.093815995847 C1226.094971518116 1951.0086624348241 1228.124492415721 1948.8405216455708 1228.2115676540711 1945.290273310452 C1228.2718345261617 1943.0500785955903 1228.2249634357522 1940.7902335088836 1228.2249634357522 1938.5369400956315 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-d1224" fill="#000000" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_4" class="path firer commentable non-processed" customid="Path 68"   datasizewidth="17.0px" datasizeheight="16.5px" dataX="1206.8" dataY="1930.7"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="17.000823974609375" height="16.494869232177734" viewBox="1206.8382812552486 1930.6628581160453 17.000823974609375 16.494869232177734" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_4-d1224" d="M1216.310271463609 1947.1577158154998 C1211.3938737702358 1947.1642660895186 1206.906154025944 1943.3258054913827 1206.8391728768195 1939.0419259000512 C1206.7721919822088 1934.8890519794265 1210.5298202681838 1930.7165274112176 1214.3946174974683 1930.6641252678714 C1219.7329945778652 1930.5855219796472 1223.8054331778017 1934.1750723078223 1223.8389237523638 1938.982973332616 C1223.8657154454781 1943.555065024693 1220.5568576657374 1947.1511666407764 1216.310271463609 1947.1577158154998 Z M1220.3894054317059 1939.5004462160375 C1220.4094996993406 1936.1139544227044 1218.2527148871357 1933.9589142473728 1214.8969722832244 1934.017866814808 C1211.923020568496 1934.0702690069575 1210.0408574963071 1936.0288009397668 1210.107838326042 1939.0157260777437 C1210.1614230397342 1941.6227352079484 1212.9947148024205 1944.0790880198622 1215.9485724279234 1944.0725375957732 C1218.6345092896058 1944.0594364352537 1220.376016611724 1942.2712118880283 1220.3894054317059 1939.5004462160375 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-d1224" fill="#000000" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
            <div id="s-Path_5" class="path firer commentable non-processed" customid="Path 69"   datasizewidth="3.6px" datasizeheight="4.6px" dataX="1222.8" dataY="1926.5"  >\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg xmlns="http://www.w3.org/2000/svg" width="3.596649169921875" height="4.624492645263672" viewBox="1222.8441264305584 1926.48883481142 3.596649169921875 4.624492645263672" preserveAspectRatio="none">\
                	  <g>\
                	    <defs>\
                	      <path id="s-Path_5-d1224" d="M1224.8540157937596 1931.1133278576638 C1223.8560004725434 1929.9539293429343 1222.7441175810834 1929.194097483561 1222.851287068354 1928.6569750457506 C1223.0053431264575 1927.8512913109494 1224.023452706575 1927.2028141623575 1224.6731673937811 1926.4888343345829 C1225.302787792143 1927.111110372459 1226.3409916511237 1927.6809842669888 1226.4347649724473 1928.368762945005 C1226.5218335036116 1929.036890897352 1225.6443854325616 1929.8294740963165 1224.8540157937596 1931.1133278576638 Z "></path>\
                	    </defs>\
                	    <g style="mix-blend-mode:normal">\
                	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
                	    </g>\
                	  </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Path_6" class="path firer commentable non-processed" customid="Icon tweter"   datasizewidth="32.1px" datasizeheight="26.9px" dataX="1130.0" dataY="1925.4"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="32.05035400390625" height="26.949216842651367" viewBox="1130.0103887930572 1925.4453279303316 32.05035400390625 26.949216842651367" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_6-d1224" d="M1130.0103887930572 1950.086163132165 C1133.218773571552 1949.06432039989 1135.8109340777082 1948.2651869330068 1138.3830004946387 1947.400550786941 C1138.858564824916 1947.2433442104925 1139.2336578307438 1946.811026127699 1139.6288451254156 1946.5228140269535 C1137.3514946787077 1945.212759193933 1135.2282003000842 1943.9813075759316 1132.4886819685119 1942.4026916020912 C1134.00245015777 1941.9703734900156 1134.7057495087638 1941.7673149893358 1135.703764989675 1941.4856532345939 C1133.7546209280567 1939.743280250455 1131.2093470027148 1938.2432676478045 1131.195950836768 1935.8262161310593 C1131.6648170840717 1935.6428084536556 1132.1336833313756 1935.4594007762516 1132.6025495387557 1935.2759931183693 C1131.9729291403937 1932.4921265982007 1131.350006825005 1929.714810502121 1130.7203864665669 1926.9309439819522 C1131.1155737213153 1926.6623827435255 1131.5107609760635 1926.3872712371806 1131.9059482707353 1926.1187099792328 C1134.9334846492516 1931.0969182822425 1139.3676200491454 1933.428815847538 1144.9672225252023 1933.5139694866464 C1145.181561379972 1933.2912601626904 1145.4427868554797 1933.1537043997573 1145.4561830613502 1932.9899475456298 C1146.192972907059 1925.5684869665429 1149.1602266186615 1923.9636699210291 1156.5080305074378 1926.6885838737628 C1157.727082806321 1927.1405527895931 1159.4016052264847 1926.433123190694 1161.1163160646418 1926.2300646900142 C1160.9756561924469 1926.583779508985 1160.8483924861987 1927.0160976210605 1160.6407517343646 1927.4156642764167 C1160.4197147766595 1927.8545326564106 1160.1249988663226 1928.2606496187277 1159.7164154057039 1928.9091267673195 C1160.6541479003115 1928.8108726509388 1161.2636740098292 1928.745369913192 1162.0607466821466 1928.660216352169 C1161.9133887169974 1929.0597830856107 1161.893294448115 1929.4331486692938 1161.6990498422658 1929.56415418383 C1159.3212281509557 1931.110018818079 1158.9327388594097 1933.2847097971653 1158.9327388594097 1935.931020847221 C1158.9394369486213 1946.9420313689363 1153.6278520341853 1952.0643455661482 1142.247798362703 1952.3329079563339 C1138.1887604001702 1952.4377116573862 1134.0761288309357 1952.706272798206 1130.0103887930572 1950.086163132165 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-d1224" fill="#000000" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Domain"   datasizewidth="220.9px" datasizeheight="25.0px" dataX="125.9" dataY="1927.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">&copy; 2024 EcoZex</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_7" class="path firer ie-background commentable non-processed" customid="Dividing line"   datasizewidth="1360.5px" datasizeheight="3.0px" dataX="5.4" dataY="1885.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="1360.5306396484375" height="2.0" viewBox="5.402328547424474 1885.8356002852042 1360.5306396484375 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_7-d1224" d="M6.402325148969908 1886.8356002852042 L1364.9329842467778 1886.8356002852042 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-d1224" fill="none" stroke-width="1.0" stroke="#FFFFFF" stroke-linecap="square"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_5" class="image firer ie-background commentable non-processed" customid="Picture_Google play"   datasizewidth="131.3px" datasizeheight="43.8px" dataX="1107.6" dataY="1771.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/1feda9dd-c561-435f-a440-94f8eaef4cd1.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_6" class="image firer ie-background commentable non-processed" customid="Picure_App store"   datasizewidth="130.6px" datasizeheight="43.8px" dataX="953.9" dataY="1772.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/4d278508-4bef-43ed-bcdb-fb9bc567e1cb.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Columns" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Column 4"   datasizewidth="227.1px" datasizeheight="208.7px" dataX="1064.9" dataY="1579.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_3_0">Other possibilities<br /></span><span id="rtr-s-Paragraph_3_1">Give away<br />subscribe<br /><br /></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Column 2"   datasizewidth="171.1px" datasizeheight="208.7px" dataX="846.4" dataY="1580.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">Help and services<br /></span><span id="rtr-s-Paragraph_5_1">How does it work<br />FAQS<br />Contact</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Column 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Tittle"   datasizewidth="394.9px" datasizeheight="38.6px" dataX="91.9" dataY="1581.1" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_6_0">Sign up for our newsletter</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Button "   datasizewidth="164.7px" datasizeheight="43.8px" dataX="91.9" dataY="1773.1" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Button_2_0">Subscribe</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
            <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="334.5px" datasizeheight="100.2px" dataX="91.9" dataY="1622.8" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_7_0">Don&#039;t worry, we reserve our newsletter for important news so we only send a few updates a year.</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable non-processed" customid="image-removebg-preview (3)"   datasizewidth="349.0px" datasizeheight="715.0px" dataX="46.0" dataY="860.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3bbbf341-ce32-4fbd-af02-5c741c834529.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_8" class="path firer commentable non-processed" customid="Menu icon"   datasizewidth="18.8px" datasizeheight="13.6px" dataX="79.3" dataY="920.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="18.83333396911621" height="13.5600004196167" viewBox="79.27494692144387 919.9999999999997 18.83333396911621 13.5600004196167" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-d1224" d="M98.10828025477721 919.9999999999997 L98.10828025477721 921.5066666666663 L79.27494692144387 921.5066666666663 L79.27494692144387 919.9999999999997 L98.10828025477721 919.9999999999997 Z M98.10828025477721 932.053333333333 L98.10828025477721 933.5599999999996 L79.27494692144387 933.5599999999996 L79.27494692144387 932.053333333333 L98.10828025477721 932.053333333333 Z M98.10828025477721 926.0266666666663 L98.10828025477721 927.533333333333 L79.27494692144387 927.533333333333 L79.27494692144387 926.0266666666663 L98.10828025477721 926.0266666666663 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-d1224" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;