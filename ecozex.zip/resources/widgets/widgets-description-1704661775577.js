	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Button_2", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Input_1", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Input_3", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_10", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Button_3", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Button_1", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "bf3793bb-2e91-4906-8a08-5c374b531345"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Path_40", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_40", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu", "s-Path_40"]; 

	widgets.descriptionMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu", "s-Path_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["H1 Heading", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Menu", "s-Path_8"]; 

	