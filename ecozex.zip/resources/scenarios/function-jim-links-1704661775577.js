(function(window, undefined) {

  var jimLinks = {
    "bf3793bb-2e91-4906-8a08-5c374b531345" : {
      "Paragraph_12" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_6" : [
        "bf3793bb-2e91-4906-8a08-5c374b531345"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);